document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.getElementById("toggle-streams");
  const toggleScro = document.getElementById("toggle-scroll-yt");

  chrome.storage.sync.get(["removeTwitchStreams", "addScrollToYT"], (data) => {
    toggle.checked = data.removeTwitchStreams ?? true; // Default to true if not set
    toggleScro.checked = data.addScrollToYT ?? true; // Default to true if not set
  });

  // Save the new setting when the toggle changes
  toggle.addEventListener("change", function () {
    chrome.storage.sync.set({ removeTwitchStreams: toggle.checked }, function () {
      console.log("Twitch streams removal: " + (toggle.checked ? "enabled" : "disabled"));
    });
  });

  toggleScro.addEventListener("change", function () {
    chrome.storage.sync.set({ addScrollToYT: toggleScro.checked }, function () {
      console.log("Scroll to YT side videos: " + (toggleScro.checked ? "enabled" : "disabled"));
    });
  });
});
