let currentButton = null;
let currentURL = window.location.href;

// Function to check if an element is scrollable
function isElementScrollable(selector) {
    const element = document.querySelector(selector);
    return element && (element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth);
}

// Function to check if an element is visible in the viewport
function isElementOnScreen(selector) {
    const element = document.querySelector(selector);
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return (
        rect.top < (window.innerHeight || document.documentElement.clientHeight) &&
        rect.left < (window.innerWidth || document.documentElement.clientWidth) &&
        rect.bottom > 0 &&
        rect.right > 0
    );
}

// Function to update the button position based on visibility and scrollability of another element
function updateButtonPosition(button) {
    const targetElement = '.style-scope ytd-engagement-panel-title-header-renderer';
    if (isElementScrollable(targetElement)) {
        button.style.top = '38%'; // Adjust as needed
        button.style.right = '-12.2%'; // Adjust as needed
    } else if (isElementOnScreen(targetElement)) {
        button.style.top = '38%'; // Adjust as needed
        button.style.right = '2.8%'; // Adjust as needed
    } else {
        button.style.top = '38%'; // Adjust as needed
        button.style.right = '-12.2%'; // Adjust as needed
    }
}

// Function to add a button to the specified div
function addButtonToDiv() {
    const targetDiv = document.querySelector('.style-scope ytd-reel-player-overlay-renderer');
    
    if (targetDiv) {
        console.log('Target div found.');

        // Remove the old button if it exists
        if (currentButton) {
            currentButton.remove();
        }

        const button = document.createElement('button');
        button.textContent = '1';
        button.style.backgroundColor = '#222';
        button.style.color = '#fff';
        button.style.fontSize = '15px';
        button.style.cursor = 'pointer';
        button.style.position = 'absolute';
        button.style.zIndex = '99999';
        button.style.pointerEvents = 'auto';
        button.style.borderRadius = '50%';
        button.style.width = '47px';
        button.style.height = '47px';
        button.style.display = 'flex';
        button.style.alignItems = 'center';
        button.style.justifyContent = 'center';
        
        let playbackRates = [1, 1.5, 2];
        let currentRateIndex = 0;
        
        function updateSpeed() {
            console.log('Button clicked');
            let currentRate = playbackRates[currentRateIndex];
            button.textContent = currentRate;
            const videoElement = document.querySelector('video');
            if (videoElement) {
                videoElement.playbackRate = currentRate;
            }
            currentRateIndex = (currentRateIndex + 1) % playbackRates.length;
        }
        
        button.addEventListener('click', updateSpeed);
        targetDiv.appendChild(button);
        targetDiv.style.position = 'relative';
        
        currentButton = button;
        updateButtonPosition(button);
        setInterval(() => updateButtonPosition(button), 100);
    } else {
        console.log('Target div not found.');
    }
}

function handleURLChange() {
    var newURL = window.location.href;
    if (newURL !== currentURL) {
        console.log('URL changed, waiting before updating button...');
        currentURL = newURL;
        setTimeout(() => {
            console.log('Updating button...');
            addButtonToDiv();
        }, 500); // Waits for 500 milliseconds (0.5 seconds)
    }
}


// Set up event listeners and periodic URL check
window.addEventListener('popstate', handleURLChange);
setInterval(handleURLChange, 500);

// Initial button setup
console.log('Script has been loaded');
addButtonToDiv();