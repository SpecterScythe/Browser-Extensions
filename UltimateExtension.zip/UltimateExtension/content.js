let observer;
function removeTwitchTopStreams() {
  const element = document.querySelector('[data-a-target="front-page-carousel"]');
  const pauseButton = document.querySelector('[data-a-target="player-mute-unmute-button"]');

  if (element) {
    element.style.position = 'absolute';
    element.style.top = '-9999px';
    element.style.left = '-9999px';
    element.style.visibility = 'hidden';
    function clickPauseButton() {
      if (pauseButton) {
        pauseButton.click();
        console.log("Pause button clicked.");
        element.remove();
        console.log("Twitch top streams section removed.");
      } else {
        setTimeout(clickPauseButton, 100);
      }
    }
    clickPauseButton();
  }
}
function setupObserver() {
  if (observer) {
    observer.disconnect();
  }
  observer = new MutationObserver(removeTwitchTopStreams);
  observer.observe(document.body, { childList: true, subtree: true });
}
function initialize() {
  chrome.storage.sync.get("removeTwitchStreams", (data) => {
    if (data.removeTwitchStreams) {
      removeTwitchTopStreams();
      setupObserver();
    } else {
      if (observer) {
        observer.disconnect();
        console.log("MutationObserver disconnected.");
      }
    }
  });
}
initialize();
//i hate twich for how it has to work, if you remove the streams at the top it does not remove the audio because the audio part does not load until the stream itself not the page of streams load which means you either have to wait 4 seconds until all the streams and all the audio loads to delete it or have effectivly undeletable audio by deleting the stream section first. so the solution is to hide the stream section and wait until the mute button is shown, or by that definition the audio is playing, then click it just for good measure. then delete the section of the top streams