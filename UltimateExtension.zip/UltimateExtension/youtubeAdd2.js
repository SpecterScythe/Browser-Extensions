function makeSecondaryScrollable() {
    const style = document.createElement('style');
    style.innerHTML = `
        #secondary {
            max-height: 95vh; /* Adjust this value to reduce the height */
            overflow-y: auto;
            scrollbar-width: thin;
            position: fixed; /* Make the element fixed */
            bottom: 0; /* Align to the bottom of the viewport */
            right: 0; /* Align to the right side of the viewport */
            width: 300px; /* Adjust width as needed */
            z-index: 9999; /* Ensure it stays on top of other elements */
        }

        #secondary::-webkit-scrollbar {
            width: 8px;
        }

        #secondary::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }
    `;
    document.head.appendChild(style);
    console.log('Custom scrollable style applied to secondary videos.');

    const secondary = document.querySelector('#secondary');
    if (secondary) {
        // Function to sync the secondary scrollbar's position with the main page's scrollbar
        function syncSecondaryPosition() {
            const scrollTop = window.scrollY; // Main page's scroll position
            // Adjust the position to stay within view
            secondary.style.top = `${scrollTop + window.innerHeight - secondary.offsetHeight}px`;
        }

        // Initial call to position the secondary scrollbar correctly
        syncSecondaryPosition();

        // Update the position on scroll
        window.addEventListener('scroll', syncSecondaryPosition);

        // Add event listener for scroll on the custom scrollbar
        secondary.addEventListener('scroll', () => {
            // Check how far down the user has scrolled in the custom scrollbar
            const scrollBottom = secondary.scrollTop + secondary.clientHeight;
            const scrollThreshold = secondary.scrollHeight - 50; // Trigger near the bottom

            // If near the bottom, simulate a scroll event to trigger YouTube's lazy load
            if (scrollBottom >= scrollThreshold) {
                console.log('Near the bottom of the secondary videos. Triggering lazy load.');

                // Programmatically trigger a scroll event on the main window
                window.dispatchEvent(new Event('scroll'));
            }
        });
    }
}

function initialize() {
    chrome.storage.sync.get("addScrollToYT", (data) => {
        if (data.addScrollToYT) {
            makeSecondaryScrollable();
            // Ensure the custom scrollbar is updated correctly on load
            window.addEventListener('load', makeSecondaryScrollable);
        }
    });
}

// Call initialize to apply settings
initialize();