// Function to fetch dislike count from the API
console.log('Script loaded')
function fetchDislikeCount(videoId) {
    const url = `https://returnyoutubedislikeapi.com/votes?videoId=${videoId}`;
    console.log('Fetching dislike count for video ID:', videoId);
    return fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log('Fetched dislike count:', data.dislikes);
            return data.dislikes;
        })
        .catch(err => {
            console.error('Failed to fetch dislike count:', err);
            return null;
        });
}

// Function to replace YouTube's default dislike button with custom button
function replaceDislikeButton(dislikeCount) {
    const dislikeButton = document.querySelector('.YtDislikeButtonViewModelHost');
    console.log('Trying to replace dislike button. Found:', dislikeButton);
    
    if (dislikeButton && dislikeCount !== null) {
        console.log('Replacing dislike button with custom button.');
        const customDislikeButton = `
            <button class="yt-spec-button-shape-next custom-dislike-button">
                <div class="yt-spec-button-shape-next__icon">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" viewBox="0 0 24 24" focusable="false">
                        <path d="M17,4h-1H6.57C5.5,4,4.59,4.67,4.38,5.61l-1.34,6C2.77,12.85,3.82,14,5.23,14h4.23l-1.52,4.94C7.62,19.97,8.46,21,9.62,21 c0.58,0,1.14-0.24,1.52-0.65L17,14h4V4H17z M10.4,19.67C10.21,19.88,9.92,20,9.62,20c-0.26,0-0.5-0.11-0.63-0.3 c-0.07-0.1-0.15-0.26-0.09-0.47l1.52-4.94l0.4-1.29H9.46H5.23c-0.41,0-0.8-0.17-1.03-0.46c-0.12-0.15-0.25-0.4-0.18-0.72l1.34-6 C5.46,5.35,5.97,5,6.57,5H16v8.61L10.4,19.67z M20,13h-3V5h3V13z"></path>
                    </svg>
                </div>
                <div class="yt-spec-button-shape-next__button-text-content">
                    <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap">${dislikeCount}</span>
                </div>
            </button>`;

        // Replace the original dislike button with the custom one
        dislikeButton.innerHTML = customDislikeButton;
        console.log('Dislike button replaced');
    } else {
        console.warn('Dislike button or dislike count not found, cannot replace.');
    }
}

// Function to extract video ID from the URL
function getVideoId() {
    const params = new URLSearchParams(window.location.search);
    const videoId = params.get('v');
    console.log('Extracted video ID:', videoId);
    return videoId;
}

// Use MutationObserver to watch for changes in the ytd-watch-metadata element
const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        if (document.querySelector('YtSegmentedLikeDislikeButtonViewModelSegmentedButtonsWrapper')) {
            if (dislikeButton) {
                console.log('Dislike button found, fetching dislike count.');
                observer.disconnect(); // Stop observing once the button is found
                const videoId = getVideoId(); // Extract video ID from URL
                if (videoId) {
                    fetchDislikeCount(videoId).then(dislikeCount => {
                        replaceDislikeButton(dislikeCount);
                        console.log('Dislike button processed.');
                    });
                }
            } else {
                console.log('Dislike button not found yet.');
            }
            observer.disconnect(); // Stop observing after the buttons are added
        }
    });
});
observer.observe(document.body, { childList: true, subtree: true });

// Fallback in case MutationObserver doesn’t work
setTimeout(replaceDislikeButton, 1000); // Adjust the delay as needed
